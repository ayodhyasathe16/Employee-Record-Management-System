  <ul class="navbar-nav bg-danger sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="myprofile.php">
        <div class="sidebar-brand-icon rotate-n-15">
          <i class="fas fa-laugh-wink"></i> 
        </div>
        <div class="sidebar-brand-text mx-3"><b>ERMS</b> </div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item">
        <a class="nav-link" href="welcome.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span><b>Dashboard</b></span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        <b>Interface</b>
      </div>

    

      <!-- Nav Item - Utilities Collapse Menu -->
     
      <!-- Nav Item - Tables -->
      <li class="nav-item">
        <a class="nav-link" href="myeducation.php">
          <i class="fas fa-fw fa-table"></i>
          <span><b>My Education</b></span></a>
      </li>
<li class="nav-item">
        <a class="nav-link" href="editmyeducation.php">
          <i class="fas fa-fw fa-table"></i>
          <span><b>Edit My Education</b></span></a>
      </li>
      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>